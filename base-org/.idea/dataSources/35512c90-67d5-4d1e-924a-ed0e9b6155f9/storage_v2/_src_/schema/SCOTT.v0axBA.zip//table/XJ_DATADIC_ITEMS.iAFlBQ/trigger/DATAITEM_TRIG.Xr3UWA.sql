CREATE TRIGGER DATAITEM_TRIG
BEFORE INSERT
  ON XJ_DATADIC_ITEMS
FOR EACH ROW WHEN (FOR EACH ROW )
begin

 select dzqc_sequence.nextval into:new.DATAITEM_CODE from dual;

end;
/
